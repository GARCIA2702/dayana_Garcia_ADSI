function mensaje(){
    alert("La pelicula mas vista por nuestros fans");
}
function intercambioImagen(ruta){
    document.getElementById("imgInicio").src = ruta;
}